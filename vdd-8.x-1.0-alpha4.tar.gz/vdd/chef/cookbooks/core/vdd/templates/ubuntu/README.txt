You can copy templates which you want to override from default folder into this
folder. For example, see vdd-php.ini.erb. It's overriden.
