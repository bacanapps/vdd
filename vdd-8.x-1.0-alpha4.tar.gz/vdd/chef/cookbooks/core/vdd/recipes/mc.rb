  package "mc" do
    action :install
  end
