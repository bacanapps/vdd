package "curl" do
  action :install
end
