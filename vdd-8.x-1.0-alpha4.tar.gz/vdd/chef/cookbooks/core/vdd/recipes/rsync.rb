package "rsync" do
  action :install
end
