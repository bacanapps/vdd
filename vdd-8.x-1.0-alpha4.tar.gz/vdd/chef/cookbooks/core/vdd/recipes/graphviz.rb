package "graphviz" do
  action :install
end
