php_pear "uploadprogress" do
  action :install
end
