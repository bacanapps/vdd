package "vim" do
  action :install
end