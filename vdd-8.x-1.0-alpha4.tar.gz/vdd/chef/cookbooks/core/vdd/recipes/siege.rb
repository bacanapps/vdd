package "siege" do
  action :install
end